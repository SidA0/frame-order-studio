"""Create additive 45-degree end stock in a separate numbered STEP folder.

Only a result that contains the source solid, remains a valid single solid, and
has two verified 45-degree planar end faces is marked reviewed. Other numbered
parts are retained with an explicit NEEDS-CAD-REVIEW suffix.
"""
import csv,glob,io,json,math,os,sys,zipfile
from OCP.BRep import BRep_Tool
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common,BRepAlgoAPI_Cut
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRep import BRep_Builder
from OCP.BRepAdaptor import BRepAdaptor_Curve,BRepAdaptor_Surface
from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet
from OCP.BRepGProp import BRepGProp
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox,BRepPrimAPI_MakeCylinder,BRepPrimAPI_MakeHalfSpace
from OCP.GeomAbs import GeomAbs_Cylinder,GeomAbs_Plane
from OCP.GProp import GProp_GProps
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_AsIs,STEPControl_Reader,STEPControl_Writer
from OCP.TopAbs import TopAbs_EDGE,TopAbs_FACE,TopAbs_SOLID,TopAbs_VERTEX
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS,TopoDS_Compound
from OCP.gp import gp_Ax2,gp_Dir,gp_Pln,gp_Pnt
import laser_tilt_audit as audit

def load(path):
    reader=STEPControl_Reader()
    if reader.ReadFile(path)!=IFSelect_RetDone:raise ValueError('Cannot read STEP')
    reader.TransferRoots();return reader.OneShape()
def write_step(shape,path):
    writer=STEPControl_Writer();writer.Transfer(shape,STEPControl_AsIs)
    if writer.Write(path)!=IFSelect_RetDone:raise ValueError('Cannot write STEP')
def volume(shape):
    properties=GProp_GProps();BRepGProp.VolumeProperties_s(shape,properties);return properties.Mass()
def solids(shape):
    explorer=TopExp_Explorer(shape,TopAbs_SOLID);count=0
    while explorer.More():count+=1;explorer.Next()
    return count

def dot(a,b):return sum(x*y for x,y in zip(a,b))
def sub(a,b):return [x-y for x,y in zip(a,b)]
def add(a,b):return [x+y for x,y in zip(a,b)]
def mul(a,c):return [x*c for x in a]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def norm(a):return math.sqrt(dot(a,a))
def unit(a):return mul(a,1/norm(a))

def axis_points(shape,axis):
    d=axis['direction'];p=axis['point'];u=unit(cross(d,[0,0,1] if abs(d[2])<.9 else [0,1,0]));v=cross(d,u)
    e=TopExp_Explorer(shape,TopAbs_VERTEX);points=[]
    while e.More():
        xyz=audit.coords(BRep_Tool.Pnt_s(TopoDS.Vertex_s(e.Current())));delta=sub(xyz,p)
        points.append((dot(delta,d),dot(delta,u),dot(delta,v)))
        e.Next()
    return points,u,v

def fit_end(points,lo,hi,side,radius,square=False):
    near=[point for point in points if (point[0]<lo+max(2*radius,(hi-lo)*.10) if side=='lo' else point[0]>hi-max(2*radius,(hi-lo)*.10)) and (square or abs(math.hypot(point[1],point[2])-radius)<.3)]
    if len(near)<(4 if square else 5):raise ValueError(f'{side}: insufficient outer end points')
    mean=[sum(point[i] for point in near)/len(near) for i in range(3)]
    suu=sum((p[1]-mean[1])**2 for p in near);svv=sum((p[2]-mean[2])**2 for p in near)
    suv=sum((p[1]-mean[1])*(p[2]-mean[2]) for p in near)
    sut=sum((p[1]-mean[1])*(p[0]-mean[0]) for p in near)
    svt=sum((p[2]-mean[2])*(p[0]-mean[0]) for p in near)
    det=suu*svv-suv*suv
    a,b=((sut*svv-svt*suv)/det,(svt*suu-sut*suv)/det) if abs(det)>1e-6 else (1,0)
    length=math.hypot(a,b)
    if length<.02:a,b=1,0
    else:a,b=a/length,b/length
    return a,b,len(near)

def ring(axis,u,v,lo,hi,R,wall):
    d=axis['direction'];p=axis['point'];start=add(p,mul(d,lo))
    outer=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(*start),gp_Dir(*d)),R,hi-lo).Shape()
    bore_start=add(start,mul(d,-1))
    inner=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(*bore_start),gp_Dir(*d)),R-wall,hi-lo+2).Shape()
    op=BRepAlgoAPI_Cut(outer,inner);op.Build()
    return op.Shape()

def clip(shape,axis,u,v,a,b,c,interior):
    normal=unit(sub(sub(axis['direction'],mul(u,a)),mul(v,b)))
    point=add(axis['point'],mul(axis['direction'],c))
    plane=gp_Pln(gp_Pnt(*point),gp_Dir(*normal))
    face=BRepBuilderAPI_MakeFace(plane,-2000,2000,-2000,2000).Face()
    half=BRepPrimAPI_MakeHalfSpace(face,gp_Pnt(*interior)).Solid()
    op=BRepAlgoAPI_Common(shape,half);op.Build()
    if not op.IsDone():raise ValueError('plane clip failed')
    return op.Shape()

def make(shape,axis,wall):
    points,u,v=axis_points(shape,axis);ts=[p[0] for p in points];lo,hi=min(ts),max(ts);R=axis['outer_radius_mm'];
    low=fit_end(points,lo,hi,'lo',R);high=fit_end(points,lo,hi,'hi',R)
    stock=ring(axis,u,v,lo-2*R-2,hi+2*R+2,R,wall)
    mid=add(axis['point'],mul(axis['direction'],(lo+hi)/2))
    for margin in [.1,.25,.5,1,2,4,8]:
        low_c=min(t-low[0]*x-low[1]*y for t,x,y in points)-margin
        high_c=max(t-high[0]*x-high[1]*y for t,x,y in points)+margin
        prepared=clip(stock,axis,u,v,*low[:2],low_c,mid)
        prepared=clip(prepared,axis,u,v,*high[:2],high_c,mid)
        if solids(prepared)!=1 or not BRepCheck_Analyzer(prepared).IsValid():continue
        removed=BRepAlgoAPI_Cut(shape,prepared);removed.Build()
        if removed.IsDone() and volume(removed.Shape())<.01:
            return prepared,{'low':low,'high':high,'margin':margin,'added_pct':100*(volume(prepared)/volume(shape)-1),'removed_mm3':volume(removed.Shape())}
    raise ValueError('source is not contained by 45-degree nominal tube stock')

def make_square(shape,wall):
    e=TopExp_Explorer(shape,TopAbs_VERTEX);xyz=[]
    while e.More():xyz.append(audit.coords(BRep_Tool.Pnt_s(TopoDS.Vertex_s(e.Current()))));e.Next()
    mins=[min(p[k] for p in xyz) for k in range(3)];maxs=[max(p[k] for p in xyz) for k in range(3)]
    k=max(range(3),key=lambda i:maxs[i]-mins[i]);other=[i for i in range(3) if i!=k]
    d=[1 if i==k else 0 for i in range(3)];u=[1 if i==other[0] else 0 for i in range(3)];v=[1 if i==other[1] else 0 for i in range(3)]
    point=[(mins[i]+maxs[i])/2 if i!=k else 0 for i in range(3)]
    axis={'direction':d,'point':point}
    points=[(p[k],p[other[0]]-point[other[0]],p[other[1]]-point[other[1]]) for p in xyz]
    lo,hi=mins[k],maxs[k];R=max(maxs[i]-mins[i] for i in other)/2
    low=fit_end(points,lo,hi,'lo',R,square=True);high=fit_end(points,lo,hi,'hi',R,square=True)
    out_lo=mins[:];out_hi=maxs[:];out_lo[k]-=2*R+2;out_hi[k]+=2*R+2
    inner_lo=out_lo[:];inner_hi=out_hi[:]
    inner_lo[k]-=1;inner_hi[k]+=1
    # A 0.01 mm envelope absorbs STEP round-off while preserving nominal size.
    for i in other:
        out_lo[i]-=.01;out_hi[i]+=.01
        inner_lo[i]+=wall+.01;inner_hi[i]-=wall+.01
    face_explorer=TopExp_Explorer(shape,TopAbs_FACE);corner_radii=[]
    while face_explorer.More():
        surface=BRepAdaptor_Surface(TopoDS.Face_s(face_explorer.Current()))
        if surface.GetType()==GeomAbs_Cylinder:
            cylinder=surface.Cylinder()
            if abs(dot(audit.coords(cylinder.Axis().Direction()),d))>.99 and cylinder.Radius()<5:corner_radii.append(cylinder.Radius())
        face_explorer.Next()
    unique=sorted(set(round(r,3) for r in corner_radii))
    if len(unique)<2:raise ValueError('Square corner radii not identified')
    outer_radius,inner_radius=max(unique),min(unique)
    def round_edges(box,radius):
        fillet=BRepFilletAPI_MakeFillet(box);edges=TopExp_Explorer(box,TopAbs_EDGE)
        while edges.More():
            edge=TopoDS.Edge_s(edges.Current());curve=BRepAdaptor_Curve(edge)
            p=audit.coords(curve.Value(curve.FirstParameter()));q=audit.coords(curve.Value(curve.LastParameter()))
            if abs(q[k]-p[k])>10 and all(abs(q[i]-p[i])<.01 for i in other):fillet.Add(radius,edge)
            edges.Next()
        fillet.Build()
        if not fillet.IsDone():raise ValueError('Square corner fillet failed')
        return fillet.Shape()
    outer=round_edges(BRepPrimAPI_MakeBox(gp_Pnt(*out_lo),gp_Pnt(*out_hi)).Shape(),outer_radius)
    inner=round_edges(BRepPrimAPI_MakeBox(gp_Pnt(*inner_lo),gp_Pnt(*inner_hi)).Shape(),inner_radius)
    op=BRepAlgoAPI_Cut(outer,inner);op.Build();stock=op.Shape()
    mid=add(point,mul(d,(lo+hi)/2))
    for margin in [.1,.25,.5,1,2,4,8]:
        low_c=min(t-low[0]*x-low[1]*y for t,x,y in points)-margin
        high_c=max(t-high[0]*x-high[1]*y for t,x,y in points)+margin
        prepared=clip(stock,axis,u,v,*low[:2],low_c,mid)
        prepared=clip(prepared,axis,u,v,*high[:2],high_c,mid)
        if solids(prepared)!=1 or not BRepCheck_Analyzer(prepared).IsValid():continue
        removed=BRepAlgoAPI_Cut(shape,prepared);removed.Build()
        if removed.IsDone() and volume(removed.Shape())<.01:
            return prepared,{'low':low,'high':high,'margin':margin,'added_pct':100*(volume(prepared)/volume(shape)-1),'removed_mm3':volume(removed.Shape()),'axis':axis}
    raise ValueError('source is not contained by 45-degree nominal square stock')

def end_faces(shape,axis):
    explorer=TopExp_Explorer(shape,TopAbs_FACE);faces=[]
    while explorer.More():
        face=TopoDS.Face_s(explorer.Current());surface=BRepAdaptor_Surface(face)
        if surface.GetType()==GeomAbs_Plane:
            normal=audit.coords(surface.Plane().Axis().Direction())
            angle=math.degrees(math.acos(min(1,abs(dot(normal,axis['direction'])))))
            faces.append((angle,audit.face_area(face)))
        explorer.Next()
    return sorted((angle,area) for angle,area in faces if abs(angle-45)<.05 and area>1)

def process(input_zip,output_zip,temporary):
    with zipfile.ZipFile(input_zip) as source:
        members=source.namelist();parts=json.loads(source.read('parts.json'));specs=json.loads(source.read('specs.json'))
        if not parts or len(parts)>500 or len(specs)!=len(parts) or len(set(parts))!=len(parts):raise ValueError('Invalid part manifest')
        if any(name not in members or not name.startswith('individual-step/') or os.path.basename(name)!=name.split('/')[-1] or not name.lower().endswith('.step') for name in parts):raise ValueError('Invalid STEP path')
        original_assembly,review_assembly=TopoDS_Compound(),TopoDS_Compound();builder=BRep_Builder();builder.MakeCompound(original_assembly);builder.MakeCompound(review_assembly)
        rows=[]
        with zipfile.ZipFile(output_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as result:
            for number,(name,spec) in enumerate(zip(parts,specs),1):
                path=os.path.join(temporary,f'source-{number:03d}.step')
                with open(path,'wb') as handle:handle.write(source.read(name))
                original=load(path)
                if solids(original)!=1 or not BRepCheck_Analyzer(original).IsValid():raise ValueError(f'Balloon {number}: source is not one valid STEP solid')
                builder.Add(original_assembly,original)
                prepared=original;status='NEEDS CAD REVIEW';reason='Automatic 45-degree end stock not applicable';info={}
                if spec.get('type') in ('Round','Square') and spec.get('bendFlag')!='Bent':
                    try:
                        od=float(spec['od']);wall=float(spec['wall'])
                        if not (0<wall<od/2):raise ValueError('Invalid tube wall specification')
                        if spec['type']=='Square':
                            prepared,info=make_square(original,wall*25.4);axis=info['axis']
                        else:
                            axis=audit.main_axis(audit.load_faces(path))
                            if not axis or abs(axis['outer_radius_mm']-od*12.7)>.15:raise ValueError('Tube axis/profile inconsistent with detected specification')
                            prepared,info=make(original,axis,wall*25.4)
                        if len(end_faces(prepared,axis))<2:raise ValueError('Two 45-degree end faces were not verified')
                        export=os.path.join(temporary,f'bevel-{number:03d}.step');write_step(prepared,export)
                        roundtrip=load(export)
                        if solids(roundtrip)!=1 or not BRepCheck_Analyzer(roundtrip).IsValid():raise ValueError('STEP round trip is invalid')
                        removed=BRepAlgoAPI_Cut(original,roundtrip);removed.Build()
                        if not removed.IsDone() or volume(removed.Shape())>.01:raise ValueError('STEP round trip removed source material')
                        if len(end_faces(roundtrip,axis))<2:raise ValueError('STEP round trip lost 45-degree end faces')
                        prepared=roundtrip;status='45-DEGREE ADDITIVE BEVEL';reason='Two planar 45-degree ends; source solid preserved'
                    except (ValueError,KeyError,TypeError) as error:
                        prepared=original;status='NEEDS CAD REVIEW';reason=str(error)
                elif spec.get('bendFlag')=='Bent':reason='Bent tube needs local end-tangent axis and individual CAD work'
                elif spec.get('type')=='Square':reason='Square section or end geometry needs individual CAD review'
                review_name=os.path.basename(name)
                if status!='45-DEGREE ADDITIVE BEVEL':review_name=review_name[:-5]+'__NEEDS-CAD-REVIEW.step'
                target=f'Tube laser reviewed parts/{review_name}'
                result.writestr(name,source.read(name))
                if prepared is original:result.writestr(target,source.read(name))
                else:result.write(export,target)
                builder.Add(review_assembly,prepared)
                rows.append({'balloon':number,'source_file':os.path.basename(name),'review_file':review_name,'status':status,'reason':reason,'added_volume_percent':round(100*(volume(prepared)/volume(original)-1),3),'end_angle_deg':45 if status=='45-DEGREE ADDITIVE BEVEL' else None,'fit_direction': 'existing end trend' if status=='45-DEGREE ADDITIVE BEVEL' else None})
            for name in members:
                if name.startswith('drawings-svg/') and name.lower().endswith('.svg'):result.writestr(name,source.read(name))
                if name=='assembly-balloons.svg':result.writestr(name,source.read(name))
            original_path=os.path.join(temporary,'frame-assembly-source.step');review_path=os.path.join(temporary,'frame-assembly-laser-review.step')
            write_step(original_assembly,original_path);write_step(review_assembly,review_path)
            result.write(original_path,'frame-assembly-source.step');result.write(review_path,'frame-assembly-laser-review.step')
            result.writestr('tube-laser-review.json',json.dumps(rows,indent=2))
            csv_text=io.StringIO();writer=csv.writer(csv_text);writer.writerow(['balloon','source file','review file','status','added volume percent','end angle deg','reason'])
            for row in rows:writer.writerow([row['balloon'],row['source_file'],row['review_file'],row['status'],row['added_volume_percent'],row['end_angle_deg'] or '',row['reason']])
            result.writestr('tube-laser-review.csv',csv_text.getvalue())
            ready=sum(row['status']=='45-DEGREE ADDITIVE BEVEL' for row in rows)
            result.writestr('README-TUBE-LASER-REVIEW.txt',f'{len(rows)} numbered source STEP solids are in individual-step/. {len(rows)} corresponding numbered STEP solids are in Tube laser reviewed parts/. {ready} have two verified planar 45-degree end faces made by additive nominal tube stock. {len(rows)-ready} retain source geometry with a NEEDS-CAD-REVIEW suffix. See tube-laser-review.csv before use. The bevel direction follows the observed end trend; ends with no direction use a fixed local reference. Square profiles use a 0.01 mm CAD containment allowance on each cross-section side. This export does not add copes, certify the 45-degree laser-head limit around a cope, or certify assembly clearance. Bent and irregular bodies still need individual CAD review. Keep all original parts for alignment and complete individual CAD review before laser cutting.\n')
    return rows

if __name__=='__main__':
    import tempfile
    if len(sys.argv)!=3:raise SystemExit('Usage: bevel_45.py input.zip output.zip')
    with tempfile.TemporaryDirectory(prefix='frame-bevel-') as temp:rows=process(sys.argv[1],sys.argv[2],temp)
    print(json.dumps({'parts':len(rows),'reviewed':sum(row['status']=='45-DEGREE ADDITIVE BEVEL' for row in rows)}))
