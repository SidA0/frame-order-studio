@echo off
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -m venv .venv
) else (
  python -m venv .venv
)
if errorlevel 1 (
  echo Python 3.11 or 3.12 is required for CAD correction.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install "cadquery-ocp==7.9.3.1.1"
if errorlevel 1 pause
