"""Review and flatten narrow STEP tube end tips with exact OpenCascade cuts.

Input is a ZIP from the browser: candidates.json plus individual-step/*.step.
The output remains a review artifact; it does not certify cope bevels or wall cuts.
"""
import json
import os
import sys
import zipfile
import csv
import io

from laser_tilt_audit import analyze as analyze_laser_tilt

from OCP.BRep import BRep_Builder
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepGProp import BRepGProp
from OCP.BRepPrimAPI import BRepPrimAPI_MakeHalfSpace
from OCP.GProp import GProp_GProps
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_AsIs, STEPControl_Reader, STEPControl_Writer
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS_Compound
from OCP.gp import gp_Dir, gp_Pln, gp_Pnt


def volume(shape):
    props = GProp_GProps()
    BRepGProp.VolumeProperties_s(shape, props)
    return props.Mass()


def count_solids(shape):
    explorer = TopExp_Explorer(shape, TopAbs_SOLID)
    count = 0
    while explorer.More():
        count += 1
        explorer.Next()
    return count


def read_step(path):
    reader = STEPControl_Reader()
    if reader.ReadFile(path) != IFSelect_RetDone:
        raise ValueError(f"Cannot read {os.path.basename(path)}")
    reader.TransferRoots()
    shape = reader.OneShape()
    if count_solids(shape) != 1 or not BRepCheck_Analyzer(shape).IsValid():
        raise ValueError(f"Input is not one valid solid: {os.path.basename(path)}")
    return shape


def write_step(shape, path):
    writer = STEPControl_Writer()
    writer.Transfer(shape, STEPControl_AsIs)
    if writer.Write(path) != IFSelect_RetDone:
        raise ValueError(f"Could not write {os.path.basename(path)}")


def trim_tip(shape, candidate, tip):
    axis = [float(value) for value in candidate["axis"]]
    center = [float(value) for value in candidate["center"]]
    extent = float(tip["extent"])
    side = tip["side"]
    if side not in ("hi", "lo") or len(axis) != 3 or len(center) != 3:
        raise ValueError("Invalid end-tip geometry")
    # Coordinates from the browser mesh are inches; STEP geometry is millimeters.
    # Leave a plane 0.100 inch inboard of the narrow extreme, normal to tube axis.
    plane_at = (extent - 0.100 if side == "hi" else extent + 0.100) * 25.4
    origin = [25.4 * center[k] + plane_at * axis[k] for k in range(3)]
    plane = gp_Pln(gp_Pnt(*origin), gp_Dir(*axis))
    face = BRepBuilderAPI_MakeFace(plane, -2000, 2000, -2000, 2000).Face()
    half = BRepPrimAPI_MakeHalfSpace(
        face, gp_Pnt(*[25.4 * value for value in center])
    ).Solid()
    operation = BRepAlgoAPI_Common(shape, half)
    operation.Build()
    corrected = operation.Shape()
    if (
        not operation.IsDone()
        or not BRepCheck_Analyzer(corrected).IsValid()
        or count_solids(corrected) != 1
    ):
        raise ValueError("Planar cut did not leave one valid solid")
    return corrected


def process(source_zip, output_zip, temporary_dir):
    with zipfile.ZipFile(source_zip) as archive:
        members = archive.namelist()
        if "candidates.json" not in members:
            raise ValueError("Missing end-tip analysis")
        candidates = json.loads(archive.read("candidates.json"))
        by_body = {int(row["body"]): row for row in candidates}
        specs = json.loads(archive.read("specs.json")) if "specs.json" in members else []
        parts = (json.loads(archive.read("parts.json")) if "parts.json" in members
                 else sorted(name for name in members if name.startswith("individual-step/") and name.lower().endswith(".step")))
        if not parts or len(parts) > 500:
            raise ValueError("Expected 1 to 500 individual STEP solids")
        if len(set(parts)) != len(parts) or any(name not in members or not name.startswith("individual-step/") or not name.lower().endswith(".step") for name in parts):
            raise ValueError("Invalid individual STEP manifest")
        if len(by_body) > len(parts):
            raise ValueError("End-tip analysis exceeds part count")
        assembly = TopoDS_Compound()
        builder = BRep_Builder()
        builder.MakeCompound(assembly)
        audit = []
        tilt_audit = []
        with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as output:
            for index, name in enumerate(parts, 1):
                if name.split("/")[-1] != os.path.basename(name) or not name.split("/")[-1]:
                    raise ValueError("Invalid part name")
                input_path = os.path.join(temporary_dir, f"input-{index:03d}.step")
                output_path = os.path.join(temporary_dir, f"output-{index:03d}.step")
                with open(input_path, "wb") as handle:
                    handle.write(archive.read(name))
                shape = read_step(input_path)
                original_volume = volume(shape)
                ends = []
                candidate = by_body.get(index)
                if candidate:
                    for tip in candidate["ends"]:
                        shape = trim_tip(shape, candidate, tip)
                        ends.append(tip["side"])
                current_volume = volume(shape)
                loss = (original_volume - current_volume) / original_volume
                if loss < -0.00001 or loss > 0.03:
                    raise ValueError(f"Body {index}: correction removed excessive volume")
                if ends:
                    write_step(shape, output_path)
                    # Re-import what the manufacturer receives, not only the in-memory shape.
                    exported = read_step(output_path)
                    exported_volume = volume(exported)
                    if abs(exported_volume - current_volume) > max(0.01, current_volume * 0.00002):
                        raise ValueError(f"Body {index}: STEP round-trip changed volume {current_volume} -> {exported_volume}")
                    output.write(output_path, name)
                else:
                    output.writestr(name, archive.read(name))
                bend_flag = (specs[index-1].get("bendFlag", specs[index-1].get("bend", "Review"))
                             if index <= len(specs) else "Review")
                tilt_audit.append(analyze_laser_tilt(output_path if ends else input_path, index, bend_flag))
                builder.Add(assembly, shape)
                audit.append({
                    "body": index,
                    "part": os.path.basename(name),
                    "flat_ends": ends,
                    "removed_volume_percent": round(100 * loss, 4),
                    "solid_valid": True,
                    "status": "planar end-tip trim" if ends else "unchanged source",
                })
            assembly_path = os.path.join(temporary_dir, "frame-assembly-flat-tip-review.step")
            write_step(assembly, assembly_path)
            output.write(assembly_path, "frame-assembly-flat-tip-review.step")
            for name in members:
                if name.startswith("drawings-svg/") and name.lower().endswith(".svg"):
                    output.writestr(name, archive.read(name))
            output.writestr("flat-tip-audit.json", json.dumps(audit, indent=2))
            output.writestr("laser-tilt-45-audit.json", json.dumps(tilt_audit, indent=2))
            summary = io.StringIO()
            writer = csv.writer(summary)
            writer.writerow(["balloon number", "45 degree status", "max sampled tilt deg", "planar faces over 45", "curved faces over 45 candidate", "reason"])
            for row in tilt_audit:
                faces = row.get("cut_faces", [])
                writer.writerow([row["body"], row["status"], row.get("max_tilt_deg", ""),
                                 ";".join(str(f["face"]) for f in faces if f["over_45"] and f["basis"] == "sampled planar face"),
                                 ";".join(str(f["face"]) for f in faces if f["over_45"] and f["basis"] != "sampled planar face"),
                                 row.get("reason", "")])
            output.writestr("laser-tilt-45-summary.csv", summary.getvalue())
            output.writestr("README-DFM-REVIEW.txt", (
                f"{len(parts)} individual STEP solids in assembly coordinates. "
                f"{sum(bool(row['flat_ends']) for row in audit)} bodies received planar end-tip trims, "
                "each 0.100 inch inboard of a detected narrow axial extremity. "
                "The output solid and STEP round trip were checked for edited parts.\n\n"
                "REVIEW STATUS: These are geometric end-tip corrections only. The algorithm "
                "screens straight round tubes for narrow tips and does not prove the absence "
                "of all zero-thickness or feather-edge features. Square, bent, and other "
                "bodies need individual inspection. The 45 degree laser tilt and straight "
                "through-wall cope requirements have not been certified or corrected. "
                "The 45 degree audit lists confirmed sampled planar over-limit faces and "
                "curved-face candidates separately. A low sampled value is not a certification "
                "of the complete tool path. No 45 degree geometry has been changed. "
                "Recheck assembly fit, cope geometry, wall, and bend data before fabrication.\n"
            ))
    return audit


if __name__ == "__main__":
    import tempfile
    if len(sys.argv) != 3:
        raise SystemExit("Usage: dfm_flat_tips.py input.zip output.zip")
    with tempfile.TemporaryDirectory(prefix="frame-dfm-") as temp:
        result = process(sys.argv[1], sys.argv[2], temp)
    print(json.dumps({"parts": len(result), "flattened": sum(bool(x["flat_ends"]) for x in result)}))
