FRAME ORDER STUDIO — LOCAL COMPANION

1. Extract this ZIP to a writable folder.
2. Install Node.js if it is not already installed.
3. Run Start Frame Order Studio.cmd and open the local URL shown in the command window.
4. Import your multi-body STEP file. STEP analysis and normal downloads run locally in your browser.
5. For CAD correction endpoints, run Install CAD Correction.cmd once. This requires Python 3.11 or 3.12 and installs cadquery-ocp 7.9.3.1.1 into a local .venv folder.

The local correction workflow includes additive 45-degree review and flat-tip tooling. Inspect generated review outputs in CAD before release to manufacturing. This ZIP contains application code and scripts only; it does not include frame-specific CAD, drawings, or order data.
