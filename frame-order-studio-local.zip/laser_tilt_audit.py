"""Sample exact STEP cut faces for a laser-head tilt screening report.

Angles measure the departure of a straight through-wall ray from the local
radial wall normal. For a planar cut this is its exact worst-case tube angle;
curved cut faces are sampled and need a separate straightness check.
"""
import glob
import json
import math
import os
import sys

from OCP.BRep import BRep_Tool
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepGProp import BRepGProp
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.GProp import GProp_GProps
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_Reader
from OCP.TopAbs import TopAbs_FACE
from OCP.TopExp import TopExp_Explorer
from OCP.TopLoc import TopLoc_Location
from OCP.TopoDS import TopoDS
from OCP.GeomAbs import GeomAbs_Cylinder, GeomAbs_Plane


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def sub(a, b):
    return [x - y for x, y in zip(a, b)]


def cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]


def normalized(a):
    m = math.hypot(*a)
    return [x / m for x in a] if m else None


def coords(point):
    return [point.X(), point.Y(), point.Z()]


def face_area(face):
    p = GProp_GProps()
    BRepGProp.SurfaceProperties_s(face, p)
    return p.Mass()


def face_center_inches(face):
    p = GProp_GProps()
    BRepGProp.SurfaceProperties_s(face, p)
    return [round(value / 25.4, 3) for value in coords(p.CentreOfMass())]


def load_faces(path):
    reader = STEPControl_Reader()
    if reader.ReadFile(path) != IFSelect_RetDone:
        raise ValueError(f"Cannot read {path}")
    reader.TransferRoots()
    shape = reader.OneShape()
    BRepMesh_IncrementalMesh(shape, 0.15, False, 0.12, True)
    explorer = TopExp_Explorer(shape, TopAbs_FACE)
    faces = []
    while explorer.More():
        face = TopoDS.Face_s(explorer.Current())
        faces.append((face, BRepAdaptor_Surface(face), face_area(face)))
        explorer.Next()
    return faces


def main_axis(faces):
    candidates = []
    for face, surface, area in faces:
        if surface.GetType() != GeomAbs_Cylinder:
            continue
        cylinder = surface.Cylinder()
        radius = cylinder.Radius()
        if 4 <= radius <= 50:
            axis = cylinder.Axis()
            candidates.append((area, radius, coords(axis.Location()), coords(axis.Direction())))
    if not candidates:
        return None
    area, radius, point, direction = max(candidates)
    return {"point": point, "direction": direction, "outer_radius_mm": radius}


def is_wall(surface, axis):
    if surface.GetType() != GeomAbs_Cylinder:
        return False
    c = surface.Cylinder()
    direction = coords(c.Axis().Direction())
    if abs(dot(direction, axis["direction"])) < .999:
        return False
    delta = sub(coords(c.Axis().Location()), axis["point"])
    perpendicular = sub(delta, [dot(delta, axis["direction"]) * x for x in axis["direction"]])
    return math.hypot(*perpendicular) < .15 and abs(c.Radius()-axis["outer_radius_mm"]) < 4


def sampled_tilts(face, axis):
    location = TopLoc_Location()
    mesh = BRep_Tool.Triangulation_s(face, location)
    if not mesh:
        return []
    transform = location.Transformation()
    direction = axis["direction"]
    values = []
    step = max(1, mesh.NbTriangles() // 600)
    for i in range(1, mesh.NbTriangles()+1, step):
        ids = mesh.Triangle(i).Get()
        points = [coords(mesh.Node(node).Transformed(transform)) for node in ids]
        normal = normalized(cross(sub(points[1], points[0]), sub(points[2], points[0])))
        if not normal:
            continue
        center = [sum(p[k] for p in points)/3 for k in range(3)]
        delta = sub(center, axis["point"])
        radial = normalized(sub(delta, [dot(delta, direction)*x for x in direction]))
        if not radial:
            continue
        projected = math.hypot(dot(normal, radial), dot(normal, direction))
        if projected < .2:
            continue
        tilt = math.degrees(math.atan2(abs(dot(normal, radial)), abs(dot(normal, direction))))
        values.append(tilt)
    return values


def analyze(path, body, bend_flag):
    faces = load_faces(path)
    axis = main_axis(faces)
    if axis is None:
        return {"body": body, "status": "REVIEW", "reason": "No reliable round-tube cylinder axis", "cut_faces": []}
    if bend_flag == "Bent":
        return {"body": body, "status": "REVIEW", "reason": "Bent tube needs local tangent at each cut", "cut_faces": []}
    cuts = []
    for face_index, (face, surface, area) in enumerate(faces, 1):
        if is_wall(surface, axis):
            continue
        shape_type = str(surface.GetType()).split("_")[-1]
        if surface.GetType() == GeomAbs_Plane:
            normal = coords(surface.Plane().Axis().Direction())
            # Analytic upper bound; the sampled value uses this face's actual
            # trimmed perimeter and is the decision value for a planar cope.
            axial = abs(dot(normal, axis["direction"]))
            bound = math.degrees(math.acos(min(1, axial)))
            tilts = sampled_tilts(face, axis)
            angle = max(tilts) if tilts else None
            kind = "sampled planar face"
        else:
            tilts = sampled_tilts(face, axis)
            angle = max(tilts) if tilts else None
            kind = "sampled curved-face candidate"
            bound = None
        if area < 20:
            continue
        cuts.append({"face": face_index, "surface": shape_type, "area_mm2": round(area, 2),
                     "center_xyz_in": face_center_inches(face),
                     "max_tilt_deg": round(angle, 1) if angle is not None else None,
                     "planar_bound_deg": round(bound, 1) if bound is not None else None,
                     "basis": kind,
                     "over_45": angle is not None and angle > 45.0 + 0.05})
    exact = [x for x in cuts if x["over_45"] and x["basis"] == "sampled planar face"]
    curved = [x for x in cuts if x["over_45"] and x["basis"] != "sampled planar face"]
    status = "PLANAR COPE OVER 45" if exact else "CURVED COPE OVER 45 CANDIDATE" if curved else "CURVED COPE NEEDS REVIEW" if any(x["basis"] != "sampled planar face" for x in cuts) else "NO OVER-LIMIT CUT SAMPLED"
    return {"body": body, "status": status, "reason": "", "max_tilt_deg": max((x["max_tilt_deg"] for x in cuts if x["max_tilt_deg"] is not None), default=None),
            "cut_faces": cuts}


if __name__ == "__main__":
    directory, specs_path, output = sys.argv[1:4]
    specs = json.load(open(specs_path))
    rows = []
    for i, spec in enumerate(specs, 1):
        files = glob.glob(os.path.join(directory, f"{i:03d}_*.step"))
        if len(files) != 1:
            raise ValueError(f"Expected one STEP for body {i}")
        rows.append(analyze(files[0], i, spec["bend"]))
    with open(output, "w") as handle:
        json.dump(rows, handle, indent=2)
    from collections import Counter
    print(dict(Counter(row["status"] for row in rows)))
    print([(row["body"], row["status"], row.get("max_tilt_deg")) for row in rows if "OVER 45" in row["status"]])
