@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js is required to run Frame Order Studio locally.
  echo Install Node.js from https://nodejs.org/ and run this file again.
  pause
  exit /b 1
)
node server.js
if errorlevel 1 pause
