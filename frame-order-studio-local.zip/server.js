const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const os = require('node:os');

const root = path.resolve(__dirname, 'dist');
const requestedPort = Number(process.env.FRAME_STUDIO_PORT || 8765);
if (!Number.isInteger(requestedPort) || requestedPort < 1 || requestedPort > 65535) {
  console.error('FRAME_STUDIO_PORT must be a port number from 1 to 65535.');
  process.exit(1);
}

const types = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.wasm': 'application/wasm',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/plain; charset=utf-8',
};

async function correctCad(request, response, mode = 'flat') {
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'frame-flat-tips-'));
  const input = path.join(temporary, 'input.zip');
  const output = path.join(temporary, 'output.zip');
  const cleanup = () => fs.rmSync(temporary, { recursive: true, force: true });
  let size = 0;
  try {
    const file = fs.createWriteStream(input);
    for await (const chunk of request) {
      size += chunk.length;
      if (size > 250 * 1024 * 1024) throw new Error('Package exceeds 250 MB');
      if (!file.write(chunk)) await new Promise(resolve => file.once('drain', resolve));
    }
    await new Promise((resolve, reject) => file.end(error => error ? reject(error) : resolve()));
    if (!size) throw new Error('Empty STEP package');
    const bundledPython = path.join(os.homedir(), '.cache', 'codex-runtimes', 'codex-primary-runtime', 'dependencies', 'python', 'python.exe');
    const localPython = path.join(__dirname, '.venv', 'Scripts', 'python.exe');
    const python = process.env.FRAME_STUDIO_PYTHON || (fs.existsSync(localPython) ? localPython : fs.existsSync(bundledPython) ? bundledPython : 'python');
    const ocpPath = path.resolve(__dirname, '..', '..', 'ocp');
    const environment = { ...process.env };
    if (fs.existsSync(path.join(ocpPath, 'OCP'))) environment.PYTHONPATH = [ocpPath, environment.PYTHONPATH].filter(Boolean).join(path.delimiter);
    const script = mode === 'bevel' ? 'bevel_45.py' : mode === 'additive' ? 'additive_45.py' : 'dfm_flat_tips.py';
    const child = spawn(python, [path.join(__dirname, script), input, output], {
      cwd: __dirname, windowsHide: true, env: environment,
    });
    let errors = '';
    child.stderr.on('data', bytes => { errors = (errors + bytes).slice(-4000); });
    const exitCode = await new Promise((resolve, reject) => {
      child.once('error', reject);
      child.once('close', resolve);
    });
    if (exitCode !== 0) throw new Error(errors.trim() || `CAD correction exited ${exitCode}`);
    const stat = fs.statSync(output);
    response.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Length': stat.size,
      'Content-Disposition': `attachment; filename="frame-${mode === 'bevel' ? 'tube-laser' : mode === 'additive' ? 'additive-45' : 'flat-tip'}-review.zip"`,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    });
    const stream = fs.createReadStream(output);
    stream.once('close', cleanup);
    stream.pipe(response);
  } catch (error) {
    cleanup();
    if (!response.headersSent) response.writeHead(422, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end(`CAD correction failed: ${error.message}`);
  }
}

const server = http.createServer((request, response) => {
  if (request.method === 'POST' && request.url === '/api/flat-tips') {
    correctCad(request, response);
    return;
  }
  if (request.method === 'POST' && request.url === '/api/additive-45') {
    correctCad(request, response, 'additive');
    return;
  }
  if (request.method === 'POST' && request.url === '/api/bevel-45') {
    correctCad(request, response, 'bevel');
    return;
  }
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    response.writeHead(405, { Allow: 'GET, HEAD' }).end();
    return;
  }
  let relative;
  try {
    relative = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname).replace(/^\/+/, '') || 'index.html';
  } catch {
    response.writeHead(400).end('Invalid URL');
    return;
  }
  const file = path.resolve(root, relative);
  if (!file.startsWith(root + path.sep)) {
    response.writeHead(403).end('Forbidden');
    return;
  }
  fs.stat(file, (error, stat) => {
    if (error || !stat.isFile()) {
      response.writeHead(404).end('Not found');
      return;
    }
    response.writeHead(200, {
      'Content-Type': types[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Content-Length': stat.size,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    });
    if (request.method === 'HEAD') response.end();
    else fs.createReadStream(file).pipe(response);
  });
});

let port = requestedPort;
server.on('error', error => {
  if (error.code === 'EADDRINUSE' && !process.env.FRAME_STUDIO_PORT && port < requestedPort + 9) {
    port += 1;
    server.listen(port, '127.0.0.1');
    return;
  }
  console.error(error.code === 'EADDRINUSE'
    ? `Port ${port} is already in use. Close the other server or set FRAME_STUDIO_PORT to another port.`
    : error.message);
  process.exitCode = 1;
});

server.on('listening', () => {
  const url = `http://127.0.0.1:${port}/`;
  console.log(`Frame Order Studio is running at ${url}`);
  console.log('Press Ctrl+C to stop. Standard STEP analysis stays in your browser.');
  console.log('Flat-tip CAD correction uses local Python/OpenCascade on this computer.');
  if (process.platform === 'win32' && !process.argv.includes('--no-open')) {
    const browser = spawn('cmd.exe', ['/c', 'start', '', url], {
      detached: true, stdio: 'ignore', windowsHide: true,
    });
    browser.on('error', () => console.log(`Open ${url} in your browser.`));
    browser.unref();
  }
});

server.listen(requestedPort, '127.0.0.1');
