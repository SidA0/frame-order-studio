"""Add round tube stock around verified over-tilt copes without removing source material.

This prepares cope-ready blanks. It does not generate a laser toolpath or certify
curved cut faces. Unresolved bodies remain unchanged and are listed in the ZIP.
"""
import csv
import io
import json
import math
import os
import sys
import zipfile

from OCP.BRep import BRep_Builder
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Fuse
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepGProp import BRepGProp
from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder
from OCP.GProp import GProp_GProps
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_AsIs, STEPControl_Reader, STEPControl_Writer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_VERTEX
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS, TopoDS_Compound
from OCP.BRep import BRep_Tool
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt

import laser_tilt_audit as tilt


def volume(shape):
    properties = GProp_GProps()
    BRepGProp.VolumeProperties_s(shape, properties)
    return properties.Mass()


def solid_count(shape):
    explorer = TopExp_Explorer(shape, TopAbs_SOLID)
    count = 0
    while explorer.More():
        count += 1
        explorer.Next()
    return count


def read_step(path):
    reader = STEPControl_Reader()
    if reader.ReadFile(path) != IFSelect_RetDone:
        raise ValueError(f"Cannot read {os.path.basename(path)}")
    reader.TransferRoots()
    shape = reader.OneShape()
    if solid_count(shape) != 1 or not BRepCheck_Analyzer(shape).IsValid():
        raise ValueError(f"Expected one valid solid: {os.path.basename(path)}")
    return shape


def write_step(shape, path):
    writer = STEPControl_Writer()
    writer.Transfer(shape, STEPControl_AsIs)
    if writer.Write(path) != IFSelect_RetDone:
        raise ValueError(f"Cannot export {os.path.basename(path)}")


def nominal_blank(shape, axis, radius_mm, wall_mm):
    explorer = TopExp_Explorer(shape, TopAbs_VERTEX)
    projections = []
    while explorer.More():
        point = tilt.coords(BRep_Tool.Pnt_s(TopoDS.Vertex_s(explorer.Current())))
        projections.append(tilt.dot(tilt.sub(point, axis["point"]), axis["direction"]))
        explorer.Next()
    lo, hi = min(projections), max(projections)
    direction = gp_Dir(*axis["direction"])
    start = [axis["point"][i] + lo * axis["direction"][i] for i in range(3)]
    # The bore cutter projects beyond both square ends, preventing a capped bore.
    bore_start = [start[i] - axis["direction"][i] for i in range(3)]
    outer = BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(*start), direction), radius_mm, hi - lo).Shape()
    inner = BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(*bore_start), direction), radius_mm - wall_mm, hi - lo + 2).Shape()
    difference = BRepAlgoAPI_Cut(outer, inner)
    difference.Build()
    if not difference.IsDone() or not BRepCheck_Analyzer(difference.Shape()).IsValid():
        raise ValueError("Nominal annular stock is invalid")
    return difference.Shape()


def process(source_zip, output_zip, temporary_dir):
    with zipfile.ZipFile(source_zip) as source:
        members = source.namelist()
        names = json.loads(source.read("parts.json"))
        specs = json.loads(source.read("specs.json"))
        if not names or len(names) > 500 or len(specs) != len(names):
            raise ValueError("Expected matching parts and specs manifests")
        if len(set(names)) != len(names) or any(
            name not in members or not name.startswith("individual-step/") or
            name.split("/")[-1] != os.path.basename(name) or not name.lower().endswith(".step")
            for name in names
        ):
            raise ValueError("Invalid part manifest")
        source_assembly, blank_assembly = TopoDS_Compound(), TopoDS_Compound()
        builder = BRep_Builder()
        builder.MakeCompound(source_assembly)
        builder.MakeCompound(blank_assembly)
        audit = []
        with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as output:
            for index, name in enumerate(names, 1):
                input_path = os.path.join(temporary_dir, f"source-{index:03d}.step")
                export_path = os.path.join(temporary_dir, f"blank-{index:03d}.step")
                with open(input_path, "wb") as handle:
                    handle.write(source.read(name))
                original = read_step(input_path)
                builder.Add(source_assembly, original)
                spec = specs[index - 1]
                bend = spec.get("bendFlag", spec.get("bend", "Review"))
                before = tilt.analyze(input_path, index, bend)
                planar_over = any(face["basis"] == "sampled planar face" and face["over_45"] for face in before.get("cut_faces", []))
                status, reason = "unchanged", "No confirmed planar over-45 face"
                candidate = original
                if planar_over:
                    status, reason = "unresolved", "Requires manual additive CAD reconstruction"
                    if spec.get("type") == "Round" and bend != "Bent":
                        axis = tilt.main_axis(tilt.load_faces(input_path))
                        try:
                            od = float(spec["od"])
                            wall = float(spec["wall"])
                            radius = axis["outer_radius_mm"] if axis else 0
                            if not axis or not (0 < wall < od / 2) or abs(radius - od * 12.7) > .15:
                                raise ValueError("Tube axis or nominal profile is inconsistent")
                            stock = nominal_blank(original, axis, radius, wall * 25.4)
                            outside = BRepAlgoAPI_Cut(original, stock)
                            outside.Build()
                            if not outside.IsDone():
                                raise ValueError("Cannot compare source with nominal stock")
                            if solid_count(stock) != 1:
                                raise ValueError("Nominal stock is not one solid")
                            if volume(outside.Shape()) <= .01:
                                prepared = stock
                            else:
                                union = BRepAlgoAPI_Fuse(original, stock)
                                union.SetFuzzyValue(.005)
                                union.Build()
                                if not union.IsDone():
                                    raise ValueError("Additive stock union failed")
                                prepared = union.Shape()
                                if volume(prepared) / volume(original) > 1.15:
                                    raise ValueError("Additive stock would increase part volume over 15 percent")
                            if solid_count(prepared) != 1 or not BRepCheck_Analyzer(prepared).IsValid():
                                raise ValueError("Prepared blank is not one valid solid")
                            write_step(prepared, export_path)
                            candidate = read_step(export_path)
                            removed = BRepAlgoAPI_Cut(original, candidate)
                            removed.Build()
                            if not removed.IsDone() or volume(removed.Shape()) > .01:
                                raise ValueError("Round-trip export removed source material")
                            after = tilt.analyze(export_path, index, bend)
                            if any(face["basis"] == "sampled planar face" and face["over_45"] for face in after.get("cut_faces", [])):
                                raise ValueError("A planar over-45 face remains")
                            status, reason = "additive square-end blank", "Original solid contained in nominal annular stock; copes must be added"
                        except (ValueError, KeyError) as error:
                            candidate = original
                            status, reason = "unresolved", str(error)
                if status == "additive square-end blank":
                    output.write(export_path, name)
                else:
                    output.writestr(name, source.read(name))
                builder.Add(blank_assembly, candidate)
                audit.append({
                    "balloon": index, "file": os.path.basename(name), "status": status,
                    "reason": reason, "added_volume_percent": round(100 * (volume(candidate) / volume(original) - 1), 3),
                    "source_45_status": before["status"],
                })
            for name in members:
                if name.startswith("drawings-svg/") and name.lower().endswith(".svg"):
                    output.writestr(name, source.read(name))
            original_path = os.path.join(temporary_dir, "frame-assembly-source.step")
            blank_path = os.path.join(temporary_dir, "frame-assembly-additive-review.step")
            write_step(source_assembly, original_path)
            write_step(blank_assembly, blank_path)
            output.write(original_path, "frame-assembly-source.step")
            output.write(blank_path, "frame-assembly-additive-review.step")
            output.writestr("additive-45-audit.json", json.dumps(audit, indent=2))
            csv_text = io.StringIO()
            writer = csv.writer(csv_text)
            writer.writerow(["balloon", "part file", "status", "added volume percent", "source 45 degree status", "reason"])
            for row in audit:
                writer.writerow([row[key] for key in ("balloon", "file", "status", "added_volume_percent", "source_45_status", "reason")])
            output.writestr("additive-45-audit.csv", csv_text.getvalue())
            changed = [row["balloon"] for row in audit if row["status"] == "additive square-end blank"]
            unresolved = [row["balloon"] for row in audit if row["status"] == "unresolved"]
            output.writestr("README-ADDITIVE-45.txt", (
                f"{len(names)} individual positioned STEP solids. Additive square-end blanks: {changed}. "
                f"Unresolved planar 45-degree cases: {unresolved}.\n\n"
                "Every changed body contains its original solid; no source volume was removed. "
                "These blanks require new cope geometry and fit review. The source assembly provides "
                "alignment, while the additive assembly contains the prepared blanks. Where an over-limit "
                "cut cannot be safely enclosed by nominal round stock, its original solid is retained "
                "and flagged. Curved faces, straight-through-wall laser cuts, other zero-thickness tips, "
                "bent tubes, square tubes, and the complete toolpath remain to be checked. "
                "This is a DFM review export, not production-ready CAD.\n"
            ))
    return audit


if __name__ == "__main__":
    import tempfile
    if len(sys.argv) != 3:
        raise SystemExit("Usage: additive_45.py input.zip output.zip")
    with tempfile.TemporaryDirectory(prefix="frame-additive-") as temporary:
        result = process(sys.argv[1], sys.argv[2], temporary)
    print(json.dumps({"parts": len(result), "additive": sum(row["status"] == "additive square-end blank" for row in result), "unresolved": sum(row["status"] == "unresolved" for row in result)}))
